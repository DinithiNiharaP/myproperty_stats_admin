import { defineStore } from "pinia";

export const useNotificationStore = defineStore("notification_store", {
  async getAllNotificationsByUser({ commit }) {
    try {
      const res = await this.$axios.$get(
        `http://localhost:8080/notification/user/7`
      );
      return res;
    } catch (e) {
      console.error(e);
    }
  },
});
