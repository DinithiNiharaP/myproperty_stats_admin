<template>
  <div color="background">
    <div class="tw-shadow-lg py-5 px-6">
      <div dense elevation="0" color="transparent text--text" class="mb-4 mt-0 ml-2 d-flex justify-start align-center" width="46%">
        <p class="text-subtitle-2 font-weight-bold mr-2 line-height-none tw-w-24">Asset Value</p>
        <input class="ml-n1" :placeholder="units " :disabled="true" background-color="background" />
        <input class="ml-2"  :placeholder="sqft " :disabled="true" background-color="background" />
      </div>
      <!-- <apexcharts ref="chart" height="350" type="bar" class="mt-n12" :options="chart.chartOptions" :series="chart.series"></apexcharts> -->
      <div v-if="loading" height="40"></div>
      <apexcharts ref="chart" height="350" type="area" class="mt-n16" :options="chart.chartOptions" :series="chart.series"></apexcharts>
    </div>
  </div>
</template>

<script>
import VueApexCharts from 'vue-apexcharts';


export default {
  name: 'OverviewChart',
  components: {
    apexcharts: VueApexCharts,
  },
  props: {
    statistics: {
      type: [Array, Object],
      required: false,
    },
    sqft: {
      type: [String, Number],
      default: 0,
    },
    units: {
      type: [String, Number],
      default: 0,
    },
    loading: {
      type: Boolean,
      default: false,
    },
  },
  data: () => ({
    chart: {
      chartOptions: {
        chart: {
          id: 'basic-bar',
          toolbar: {
            show: false,
          },
        },
        title: {
          text: '',
          floating: true,
          style: {
            fontSize: '14px',
            fontWeight: 'bold',
            fontFamily: 'Sofia Pro',
            color: '#0F0D36',
          },
        },
        plotOptions: {
          bar: {
            horizontal: false,
            columnWidth: '24%',
            borderRadius: 2,
          },
        },
        dataLabels: {
          enabled: false,
        },
        stroke: {
          show: true,
          width: 1,
          colors: ['transparent'],
        },
        yaxis: {
          labels: {
            formatter: (val) => {
              val = val / 1000;
              return '' + parseFloat(val).toFixed(0) + 'K';
            },
          },
          title: {
            text: 'Amount ($)',
            style: {
              fontSize: '14px',
              fontWeight: '600',
              fontFamily: 'Sofia Pro',
              color: '#0F0D36',
            },
          },
        },
        xaxis: {
          categories: [1991, 1992, 1993, 1994, 1995, 1996, 1997, 1998],
        },
        fill: {
          opacity: 1,
        },
        tooltip: {
          // inverseOrder: true,
          x: {
            formatter: undefined,
          },
          y: {
            formatter: function (val) {
              // console.log(val);
              return ' $' + parseFloat(val).toFixed(0);
            },
            // formatter: function (value, { series, seriesIndex, dataPointIndex, w }) {
            //   console.log(series);
            //   console.log(seriesIndex);
            //   console.log(dataPointIndex);
            //   console.log(w);
            //   return value | currency('$');
            // },
          },
        },
        colors: ['#19BFB4', '#645CFC', '#FC5CDC', '#02B814', '#E9DC29'],
        legend: {
          show: true,
          showForSingleSeries: true,
          position: 'top',
          horizontalAlign: 'right',
          itemMargin: {
            horizontal: 15,
            vertical: 20,
          },
        },
      },
      series: [],
    },
    formData: {
      yearFilter: [0],
    },
  }),
  watch: {
    statistics: function (data) {
      console.log(data);
      this.setData(data);
    },
  },
  methods: {
    setData(statistics) {
      let assetValues = [];
      let cashflows = [];
      let debts = [];
      let equities = [];
      let revenues = [];
      let labels = [];
      for (const statistic of statistics) {
        assetValues.push(statistic.asset_value || 0);
        cashflows.push(statistic.cashflow || 0);
        debts.push(statistic.debt || 0);
        equities.push(statistic.equity || 0);
        revenues.push(statistic.revenue || 0);
        labels.push(moment(statistic.date).format('MMM YYYY'));
      }

      // let labels = [];
      // for (const year of this.formData.yearFilter) {
      //   labels.push(`Year ${year + 1}`);
      // }
      this.chart.chartOptions = {
        labels: labels,
      };
      this.$refs.chart.updateSeries([
        { name: 'Asset Value', data: assetValues },
        { name: 'Cash flow', data: cashflows },
        { name: 'Debt', data: debts },
        { name: 'Equity', data: equities },
        { name: 'Income', data: revenues },
      ]);
    },
  },
};
</script>
<style scoped>
* >>> .apexcharts-legend {
  /* margin-top: -10px !important; */
  /* position: fixed !important;
  width: 60%;
  margin-left: 40%; */
}
</style>

