<template>
  <!-- <AppLayoutMain />  -->
  <div class="container mt-8">
    <div class="container mb-4">
      <h1>
        <span class="text-neutral cursor-pointer" @click="dashboard"
          >Dashboard/
        </span>
        <span>Overview</span>
      </h1>
    </div>
    <div class="container">
      <div class="flex">
        <SelectAllField
          background-color="background"
          :items="myPortfolios"
          label="Portfolio:"
          @change="onPortfolioChange"
          :data.sync="selectedPortfolio"
        />
        <SelectAllField
          background-color="background"
          :items="allProperties"
          label="Property:"
          @change="onPropertyAllChange"
          :data.sync="selectedProperty"
        />
        <SelectAllField
          background-color="background"
          :items="owners"
          label="Owner:"
          @change="onOwnerChange"
          :value.sync="selectedOwners"
        />

        <!-- <div class="flex justify-center">
          <div class="dropdown dropdown-bottom mr-3">
            <label
              tabindex="0"
              class="flex m-1 border-solid border-2 rounded-md pl-4 pr-4 pb-2 pt-2 text-sm font-semibold text-gray-500"
            >
              Portfolio:
              <svg
                aria-hidden="true"
                focusable="false"
                data-prefix="fas"
                data-icon="caret-down"
                class="w-2 ml-8"
                role="img"
                xmlns="http://www.w3.org/2000/svg"
                viewBox="0 0 320 512"
              >
                <path
                  fill="currentColor"
                  d="M31.3 192h257.3c17.8 0 26.7 21.5 14.1 34.1L174.1 354.8c-7.8 7.8-20.5 7.8-28.3 0L17.2 226.1C4.6 213.5 13.5 192 31.3 192z"
                ></path>
              </svg>
            </label>
            <ul
              tabindex="0"
              class="dropdown-content menu p-2 shadow bg-base-100 rounded-box w-52"
            >
              <li>
                <div class="flex">
                  <input
                    id="default-checkbox"
                    type="checkbox"
                    value=""
                    class="w-4 h-4 text-primary bg-gray-100 rounded"
                  />
                  <label
                    for="default-checkbox"
                    class="ml-2 text-sm font-semibold text-secondary"
                    >Select All</label
                  >
                </div>
              </li>
              <li class="divide"></li>
              <li>
                <div class="flex">
                  <input
                    id="default-checkbox"
                    type="checkbox"
                    value=""
                    class="w-4 h-4 text-primary bg-gray-100 rounded"
                  />
                  <label
                    for="default-checkbox"
                    class="ml-2 text-sm font-semibold text-secondary"
                    >Default checkbox</label
                  >
                </div>
              </li>
            </ul>
          </div>
        </div> -->
        <!-- <div>
          <div class="dropdown dropdown-bottom mr-3">
            <label
              tabindex="0"
              class="flex m-1 border-solid border-2 rounded-md pl-4 pr-4 pb-2 pt-2 text-sm font-semibold text-gray-500"
            >
              Property:
              <svg
                aria-hidden="true"
                focusable="false"
                data-prefix="fas"
                data-icon="caret-down"
                class="w-2 ml-8"
                role="img"
                xmlns="http://www.w3.org/2000/svg"
                viewBox="0 0 320 512"
              >
                <path
                  fill="currentColor"
                  d="M31.3 192h257.3c17.8 0 26.7 21.5 14.1 34.1L174.1 354.8c-7.8 7.8-20.5 7.8-28.3 0L17.2 226.1C4.6 213.5 13.5 192 31.3 192z"
                ></path>
              </svg>
            </label>
            <ul
              tabindex="0"
              class="dropdown-content menu p-2 shadow bg-base-100 rounded-box w-52"
            >
              <li>
                <div class="flex">
                  <input
                    id="default-checkbox"
                    type="checkbox"
                    value=""
                    class="w-4 h-4 text-primary bg-gray-100 rounded"
                  />
                  <label
                    for="default-checkbox"
                    class="ml-2 text-sm font-semibold text-secondary"
                    >Select All</label
                  >
                </div>
              </li>
              <li class="divide"></li>
              <li>
                <div class="flex">
                  <input
                    id="default-checkbox"
                    type="checkbox"
                    value=""
                    class="w-4 h-4 text-primary bg-gray-100 rounded"
                  />
                  <label
                    for="default-checkbox"
                    class="ml-2 text-sm font-semibold text-secondary"
                    >Default checkbox</label
                  >
                </div>
              </li>
            </ul>
          </div>
        </div>
        <div>
          <div class="dropdown dropdown-bottom mr-3">
            <label
              tabindex="0"
              class="flex m-1 border-solid border-2 rounded-md pl-4 pr-4 pb-2 pt-2 text-sm font-semibold text-gray-500"
            >
              Owner:
              <svg
                aria-hidden="true"
                focusable="false"
                data-prefix="fas"
                data-icon="caret-down"
                class="w-2 ml-8"
                role="img"
                xmlns="http://www.w3.org/2000/svg"
                viewBox="0 0 320 512"
              >
                <path
                  fill="currentColor"
                  d="M31.3 192h257.3c17.8 0 26.7 21.5 14.1 34.1L174.1 354.8c-7.8 7.8-20.5 7.8-28.3 0L17.2 226.1C4.6 213.5 13.5 192 31.3 192z"
                ></path>
              </svg>
            </label>
            <ul
              tabindex="0"
              class="dropdown-content menu p-2 shadow bg-base-100 rounded-box w-52"
            >
              <li>
                <div class="flex">
                  <input
                    id="default-checkbox"
                    type="checkbox"
                    value=""
                    class="w-4 h-4 text-primary bg-gray-100 rounded"
                  />
                  <label
                    for="default-checkbox"
                    class="ml-2 text-sm font-semibold text-secondary"
                    >Select All</label
                  >
                </div>
              </li>
              <li class="divide"></li>
              <li>
                <div class="flex">
                  <input
                    id="default-checkbox"
                    type="checkbox"
                    value=""
                    class="w-4 h-4 text-primary bg-gray-100 rounded"
                  />
                  <label
                    for="default-checkbox"
                    class="ml-2 text-sm font-semibold text-secondary"
                    >Default checkbox</label
                  >
                </div>
              </li>
            </ul>
          </div>
        </div> -->
        <div>
          <div class="dropdown dropdown-bottom">
            <label
              tabindex="0"
              class="flex m-1 border-solid border-2 rounded-md pl-4 pr-4 pb-2 pt-2 text-sm font-semibold text-gray-500"
            >
              Date:
              <svg
                aria-hidden="true"
                focusable="false"
                data-prefix="fas"
                data-icon="caret-down"
                class="w-2 ml-8"
                role="img"
                xmlns="http://www.w3.org/2000/svg"
                viewBox="0 0 320 512"
              >
                <path
                  fill="currentColor"
                  d="M31.3 192h257.3c17.8 0 26.7 21.5 14.1 34.1L174.1 354.8c-7.8 7.8-20.5 7.8-28.3 0L17.2 226.1C4.6 213.5 13.5 192 31.3 192z"
                ></path>
              </svg>
            </label>
            <ul
              tabindex="0"
              class="dropdown-content menu p-2 shadow bg-base-100 rounded-box w-52"
            >
              <li><a>Item 1</a></li>
              <li><a>Item 2</a></li>
            </ul>
          </div>
        </div>
      </div>
      <div class="container bg-white">
        <!-- <overview-chart
          :statistics="chartStatistics"
          :units="units"
          :sqft="sqft"
          :loading="loading"
        /> -->
      </div>
      <div class="container bg-white">
        <!-- <overview-table
          :statistics="statistics"
          :startingDate="startingDate"
          :endingDate="endingDate"
        /> -->
      </div>
    </div>
  </div>
</template>
<script>
import { mapActions } from "pinia";
import axios from "axios";
import { useNotificationStore } from "../../store/notification_store";
// import moment from 'moment';
import AppLayoutMain from "../../components/app-layout-main.vue";
import OverviewChart from "../../components/chart/overview-chart.vue";
import SelectAllField from "../../components/inputs/select-all-field.vue";
export default {
  components: { AppLayoutMain, OverviewChart, SelectAllField },
  data: () => ({
    years: [],
    // proTypes: portfolioOptions,
    primaryId: 0,
    propertyId: 0,
    loading: false,
    properties: [],
    allProperties: [],
    initialProperties: [],
    initialPropertyIds: [],
    dateFilter: 1,
    selectedProperty: [],
    selectedPropertyType: [],
    Portfolios: [],
    selectedPortfolio: [],
    statistics: [],
    chartStatistics: [],
    units: 0,
    sqft: 0,
    startingDate: "",
    endingDate: "",
    isHiddenSideBar: true,
    sm: 8,
    myPortfolios: [],
    // startDate: moment(new Date()).subtract(1, 'Y').format('YYYY-MM'),
    // endDate: moment(new Date()).format('YYYY-MM'),
    selectedMonth: "",
    dateArray: [],
    // maxDate: moment(new Date()).format('YYYY-MM'),
    selectedOwners: [],
    owners: [],
    ownerTypes: [],
    ownerIds: [],
    uniqueEntities: [],
  }),
  beforeMount() {
    useNotificationStore();
    /* axios
      .get(`http://localhost:8080/notification/user/7`)
      .then(function (res) {
        console.log(res);
      })
      .catch(function (res) {
        console.log(res);
      }); */
  },
  async fetch() {
    this.generateYears();
    this.getPropertiesByFilters("");

    const res = await this.getAllNotificationsByUser();
    if (res.length === 0) {
      this.isHiddenSideBar = false;
      this.sm = 12;
    }
    this.dateArray = [this.startDate, this.endDate];
  },
  methods: {
    ...mapActions(
      /*       fetchProperties: "getProperties",
      getCurrentProperty: "../../property_store/getCurrentProperty",
      getOverviewFiltersData: "../../property_store/getOverviewFiltersData", */
      useNotificationStore,
      ["getAllNotificationsByUser"]
    ),
    dashboard() {
      this.$router.push({ name: "Dashboard" });
    },
    onDateChanged(val) {
      console.log(val);
      console.log("starteDate", val[0]);
      console.log("endDate", val[1]);
      this.startDate = val[0];
      this.endDate = val[1];
      let portfolios = [];
      for (let item of this.initialProperties) {
        for (let Property of this.selectedProperty) {
          if (Property == item.propertyId) {
            portfolios.push(item.propertyType);
          }
        }
      }
      this.onchangeFilters(this.selectedProperty, portfolios);
    },
    async getPropertiesByFilters(propertyType) {
      try {
        const res = await this.fetchProperties({
          search: "",
          propertyType: propertyType,
          status: "",
          sort: "",
        });
        for (let property of res) {
          if (property.isActive) {
            let address = property.addressLine1;
            property.text = address.slice(0, 15);
            property.value = property.propertyId;
            property.propertyType = property.propertyType;
            this.properties.push(property);
            this.allProperties.push({
              text: address.slice(0, 15),
              value: property.propertyId,
              portfolio: property.propertyType,
            });

            for (let item of this.proTypes) {
              if (item.value === property.propertyType) {
                this.myPortfolios.push(item);
              }
            }

            const unique = (value, index, self) => {
              return self.indexOf(value) === index;
            };

            this.myPortfolios = this.myPortfolios.filter(unique);

            this.initialPropertyIds.push(property.propertyId);
            this.initialProperties.push(property);
          }
        }
        this.onInitialFilters(this.initialPropertyIds);
      } catch (e) {
        console.error(e);
      } finally {
      }
    },

    async onPropertyAllChange(val) {
      this.ownerTypes = [];
      this.ownerIds = [];
      await this.updateOwnersArray(val);
      if (this.timeout >= 0) {
        clearTimeout(this.timeout);
      }
      this.timeout = setTimeout(async () => {
        this.selectedProperty = val;

        let portfolios = [];
        for (let item of this.initialProperties) {
          for (let Property of this.selectedProperty) {
            if (Property == item.propertyId) {
              portfolios.push(item.propertyType);
            }
          }
        }
        this.onchangeFilters(this.selectedProperty, portfolios);
      }, 1000);
    },

    onPortfolioChange(val) {
      console.log(val);

      if (this.timeout >= 0) {
        clearTimeout(this.timeout);
      }
      this.timeout = setTimeout(() => {
        this.selectedPropertyType = val;

        if (val.length > 0) {
          this.allProperties = [];
          for (let type of val) {
            let properties = this.initialProperties.filter((item) => {
              console.log(item);
              const propertyType = item.propertyType;
              return propertyType.includes(type);
            });
            this.allProperties = this.allProperties.concat(properties);
          }
          let newProperty = [];
          let newPropertyIds = [];
          for (let property of this.allProperties) {
            let address = property.addressLine1;
            property.text = address.slice(0, 15);
            property.value = property.propertyId;
            property.propertyType = property.propertyType;
            this.properties.push(property);
            newProperty.push({
              value: property.propertyId,
              text: address.slice(0, 15),
              portfolio: property.propertyType,
            });

            newPropertyIds.push(property.propertyId);
            this.selectedProperty = newPropertyIds;
          }
          this.allProperties = newProperty;
          console.log(this.allProperties);

          this.onchangeFilters(newPropertyIds, this.selectedPropertyType);
        } else {
          this.allProperties = [];
        }
      }, 1000);
    },

    async onchangeFilters(propertyIds, portfolios) {
      this.loading = true;
      const res = await this.getOverviewFiltersData({
        startDate: this.startDate + "-01",
        endDate: this.endDate + "-01",
        portfolios: portfolios,
        propertyIds: propertyIds,
        ownerTypes: this.ownerTypes,
        ownerIds: this.ownerIds,
      });
      console.log(res);
      this.statistics = res.statistics;
      this.chartStatistics = res.chart;
      this.startingDate = moment(res.chart[0].date).format("MMMM YYYY");
      this.endingDate = moment(res.chart[res.chart.length - 1].date).format(
        "MMMM YYYY"
      );
      this.units = res.units;
      this.sqft = res.sqft;
      this.loading = false;
    },

    async onInitialFilters(propertyIds) {
      this.loading = true;
      await this.updateOwnersArray(propertyIds);

      let allPortfolios = [];
      for (let type of this.myPortfolios) {
        allPortfolios.push(type.value);
      }
      console.log(propertyIds);
      console.log(allPortfolios);
      this.selectedPropertyType = allPortfolios;
      this.selectedProperty = propertyIds;

      const res = await this.getOverviewFiltersData({
        startDate: this.startDate + "-01",
        endDate: this.endDate + "-01",
        portfolios: allPortfolios,
        propertyIds: propertyIds,
        ownerTypes: this.ownerTypes,
        ownerIds: this.ownerIds,
      });
      console.log(res);
      this.statistics = res.statistics;
      this.chartStatistics = res.chart;
      this.startingDate = moment(res.chart[0].date).format("MMMM YYYY");
      this.endingDate = moment(res.chart[res.chart.length - 1].date).format(
        "MMMM YYYY"
      );
      this.units = res.units;
      this.sqft = res.sqft;
      this.loading = false;
    },

    generateYears() {
      let currentYear = moment(new Date()).format("YYYY");
      console.log(Number(currentYear) + 1);
      this.year = [];
      for (let i = 1; i < currentYear - 1899; i++) {
        if (i == 1)
          this.years.push({
            text: `This year (${12 * i} months ago)`,
            value: i,
          });
        else {
          this.years.push({
            text: `Last ${i} years (${12 * i} months ago)`,
            value: i,
          });
        }
      }
    },
    onClickHidden() {
      console.log(this.isHiddenSideBar);

      if (this.isHiddenSideBar == true) {
        this.sm = 12;
      } else {
        this.sm = 8;
      }
      this.isHiddenSideBar = !this.isHiddenSideBar;
    },

    async updateOwnersArray(val) {
      try {
        this.loading = true;
        let properties = val;
        console.log(val);
        this.owners = [];
        let arr = [];
        if (properties && properties.length > 0) {
          for (let propertyId of properties) {
            console.log(propertyId);
            const res = await this.getCurrentProperty({
              propertyId: propertyId,
            });
            if (res && res.entities && res.entities.length > 0) {
              arr.push(...res.entities);
            }
          }

          console.log(arr);
          const key = "taxId";

          let arrayUniqueByKey = [
            ...new Map(arr.map((item) => [item[key], item])).values(),
          ];
          this.uniqueEntities = arrayUniqueByKey;
          console.log(arrayUniqueByKey);

          for (let entity of arrayUniqueByKey) {
            if (entity.ownerType == "entity") {
              this.owners.push({
                text: entity.name + " (entity)",
                type: "entity",
                value: entity.entityId,
                entityId: entity.entityId,
                parentId: entity.parentEntityId,
              });
              if (entity && entity.owners && entity.owners.length > 0) {
                for (let owner of entity.owners) {
                  this.owners.push({
                    text: owner.fname + "" + owner.lname,
                    type: "entityOwner",
                    value: owner.ownerId,
                    entityId: entity.entityId,
                    parentId: owner.entityId,
                  });
                }
              }
            } else {
              if (entity && entity.owners && entity.owners.length > 0) {
                for (let owner of entity.owners) {
                  this.owners.push({
                    text: owner.fname + "" + owner.lname,
                    type: "singleOwner",
                    value: owner.ownerId,
                    entityId: entity.entityId,
                    parentId: entity.parentEntityId,
                  });
                }
              }
            }
          }
        }
      } catch (error) {
      } finally {
      }
    },

    onOwnerChange(obj) {
      console.log(obj);
      console.log(this.selectedOwners);
      if (this.timeout >= 0) {
        clearTimeout(this.timeout);
      }
      this.timeout = setTimeout(() => {
        console.log(obj);
        let types = [];
        if (obj && obj.length > 0) {
          for (let i = 0; i < obj.length; i++) {
            let item = this._.find(this.owners, function (owner) {
              return owner.value === obj[i];
            });
            types.push(item.type);
            if (item.type == "entity") {
              console.log("==================================");
              console.log(obj[i]);
            }
            this.getChildsByEntityId(obj[i]);
          }
        }
        if (obj.length == this.owners.length) this.selectedOwners = obj;
        // this.ownerTypes = types;
        // this.ownerIds = obj;
        // console.log(types);
        // console.log(obj);
        console.log(this.selectedOwners);
        let portfolios = [];
        for (let item of this.initialProperties) {
          for (let Property of this.selectedProperty) {
            if (Property == item.propertyId) {
              portfolios.push(item.propertyType);
            }
          }
        }
        this.onchangeFilters(this.selectedProperty, portfolios);
      }, 1000);
    },

    onChangeLength(val) {
      // if(val===0){
      //   this.isHiddenSideBar == true
      //    this.sm = 12;
      // }
      // alert(val)
    },

    async getChildsByEntityId(id) {
      var newItem1 = this.owners.filter((entity) => {
        return entity.parentId == id;
      });

      let child = this._.cloneDeep(newItem1);
      for (let item of newItem1) {
        if (item.type == "entity") {
          var newItem2 = this.owners.filter((entity) => {
            return entity.parentId == item.entityId;
          });
          newItem1.push(...newItem2);
          child.push(...newItem2);
        }
      }

      let arr = this._.cloneDeep(this.selectedOwners);
      for (let item of child) {
        let newItem2 = this._.find(arr, function (id) {
          return id == item.value;
        });
        if (!newItem2) arr.push(item.value);
      }
      this.selectedOwners = arr;

      let types = [];
      for (let selectedItem of this.selectedOwners) {
        let newItem2 = this._.find(this.owners, function (entity) {
          return entity.value == selectedItem;
        });
        types.push(newItem2.type);
      }

      this.ownerTypes = types;
      this.ownerIds = this.selectedOwners;
    },
  },
};
</script>
<style scoped>
h1 {
  color: #0f0d36;
  text-align: left;
  font-size: 20px;
  font-weight: bold;
}

p {
  width: 452px;
  text-align: center;
}

.container {
  padding-left: 8%;
}
</style>
